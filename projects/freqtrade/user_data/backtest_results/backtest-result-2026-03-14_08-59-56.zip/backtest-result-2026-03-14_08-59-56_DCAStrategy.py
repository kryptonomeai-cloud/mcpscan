from freqtrade.strategy import IStrategy, IntParameter, RealParameter
from freqtrade.persistence import Trade
from pandas import DataFrame
import talib.abstract as ta
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class DCAStrategy(IStrategy):
    """Dollar Cost Averaging strategy.

    Entry: RSI oversold with EMA trend confirmation.
    DCA:   Scale into positions at -3%, -6%, -9% drawdown levels.
    Exit:  Take profit at mean reversion targets or trailing stop.
    Works well in volatile/bear markets by averaging down entry price.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.08,
        "60": 0.05,
        "120": 0.03,
        "240": 0.015,
    }

    stoploss = -0.15  # Wider stop for DCA

    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 50

    position_adjustment_enable = True
    max_entry_position_adjustment = 3  # Up to 3 additional entries

    # Hyperopt params
    buy_rsi_threshold = IntParameter(15, 40, default=30, space='buy', optimize=True)
    buy_ema_fast = IntParameter(8, 25, default=12, space='buy', optimize=True)
    buy_ema_slow = IntParameter(20, 55, default=26, space='buy', optimize=True)

    sell_rsi_threshold = IntParameter(60, 85, default=70, space='sell', optimize=True)

    # DCA levels
    dca_level_1 = RealParameter(-0.01, -0.05, default=-0.03, decimals=2, space='buy', optimize=True)
    dca_level_2 = RealParameter(-0.04, -0.08, default=-0.06, decimals=2, space='buy', optimize=True)
    dca_level_3 = RealParameter(-0.07, -0.12, default=-0.09, decimals=2, space='buy', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs
        for period in range(8, 56):
            dataframe[f'ema{period}'] = ta.EMA(dataframe, timeperiod=period)

        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Bollinger Bands
        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_lower'] = bb['lowerband']

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        fast_col = f'ema{self.buy_ema_fast.value}'
        slow_col = f'ema{self.buy_ema_slow.value}'

        dataframe.loc[
            (
                (dataframe['rsi'] < self.buy_rsi_threshold.value) &
                (dataframe[fast_col] > dataframe[slow_col]) &
                (dataframe['close'] < dataframe['bb_middle']) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > self.sell_rsi_threshold.value) |
                (dataframe['close'] > dataframe['bb_upper'])
            ),
            'exit_long'] = 1
        return dataframe

    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float,
                              min_stake: float | None, max_stake: float | None,
                              current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float,
                              **kwargs) -> float | None | tuple[float | None, str]:
        """Scale into position at defined DCA levels."""
        if current_profit > self.dca_level_1.value:
            return None

        filled_entries = trade.nr_of_successful_entries
        stake_amount = trade.stake_amount

        if filled_entries == 1 and current_profit <= self.dca_level_1.value:
            # First DCA: same size as initial
            return stake_amount
        elif filled_entries == 2 and current_profit <= self.dca_level_2.value:
            # Second DCA: 1.5x initial
            return stake_amount * 1.5
        elif filled_entries == 3 and current_profit <= self.dca_level_3.value:
            # Third DCA: 2x initial
            return stake_amount * 2.0

        return None
