from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, RealParameter
from pandas import DataFrame
import talib.abstract as ta
import numpy as np


class MomentumTrendStrategy(IStrategy):
    """Momentum + Trend strategy using ADX, Stochastic RSI, and ATR.

    Entry: ADX > threshold (strong trend), StochRSI oversold crossover,
           price above EMA200 (uptrend filter).
    Exit:  StochRSI overbought or ADX declining.
    ATR-based dynamic stop loss.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.12,
        "60": 0.06,
        "120": 0.03,
        "240": 0.015,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.07
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 200

    # Hyperopt params
    buy_adx_threshold = IntParameter(15, 40, default=25, space='buy', optimize=True)
    buy_stochrsi_threshold = IntParameter(10, 35, default=20, space='buy', optimize=True)
    buy_ema_trend = IntParameter(100, 250, default=200, space='buy', optimize=True)

    sell_stochrsi_threshold = IntParameter(70, 95, default=80, space='sell', optimize=True)
    sell_adx_decline = IntParameter(1, 10, default=3, space='sell', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['adx_prev'] = dataframe['adx'].shift(1)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14)

        # Stochastic RSI
        rsi = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi'] = rsi
        stoch_rsi_period = 14
        dataframe['stochrsi'] = (
            (rsi - rsi.rolling(stoch_rsi_period).min()) /
            (rsi.rolling(stoch_rsi_period).max() - rsi.rolling(stoch_rsi_period).min())
        ) * 100
        dataframe['stochrsi_k'] = dataframe['stochrsi'].rolling(3).mean()
        dataframe['stochrsi_d'] = dataframe['stochrsi_k'].rolling(3).mean()
        dataframe['stochrsi_k_prev'] = dataframe['stochrsi_k'].shift(1)
        dataframe['stochrsi_d_prev'] = dataframe['stochrsi_d'].shift(1)

        # EMA trend filters
        for period in [100, 150, 200, 250]:
            dataframe[f'ema{period}'] = ta.EMA(dataframe, timeperiod=period)

        # ATR for dynamic stops
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        # MACD for confirmation
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Round trend EMA to nearest 50
        trend_val = round(self.buy_ema_trend.value / 50) * 50
        if trend_val < 100:
            trend_val = 100
        trend_col = f'ema{trend_val}'

        dataframe.loc[
            (
                (dataframe['adx'] > self.buy_adx_threshold.value) &
                (dataframe['plus_di'] > dataframe['minus_di']) &
                (dataframe['stochrsi_k'] < self.buy_stochrsi_threshold.value) &
                (dataframe['stochrsi_k'] > dataframe['stochrsi_d']) &
                (dataframe['stochrsi_k_prev'] <= dataframe['stochrsi_d_prev']) &
                (dataframe['close'] > dataframe[trend_col]) &
                (dataframe['macdhist'] > 0) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['stochrsi_k'] > self.sell_stochrsi_threshold.value) |
                (
                    (dataframe['adx'] < dataframe['adx_prev'] - self.sell_adx_decline.value) &
                    (dataframe['adx'] < 25)
                ) |
                (dataframe['plus_di'] < dataframe['minus_di'])
            ),
            'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade, current_time, current_rate,
                        current_profit, after_fill, **kwargs):
        """ATR-based dynamic stop loss."""
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) < 1:
            return self.stoploss

        last_candle = dataframe.iloc[-1]
        atr = last_candle.get('atr', 0)
        if atr == 0:
            return self.stoploss

        # Stop loss at 2x ATR from current price
        atr_stop = -(atr * 2) / current_rate
        return max(atr_stop, self.stoploss)
