from freqtrade.strategy import IStrategy, IntParameter, RealParameter
from pandas import DataFrame
import talib.abstract as ta


class BearShortStrategy(IStrategy):
    """Short-selling strategy for bear markets.

    Entry Short: EMA death cross (fast below slow), RSI overbought, price below EMA200.
    Exit Short:  EMA golden cross or RSI oversold.
    Designed specifically for downtrending markets.
    """

    INTERFACE_VERSION = 3
    can_short = True

    minimal_roi = {
        "0": 0.10,
        "60": 0.05,
        "120": 0.03,
        "240": 0.01,
    }

    stoploss = -0.08

    trailing_stop = True
    trailing_stop_positive = 0.025
    trailing_stop_positive_offset = 0.05
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 250

    # Hyperopt params
    buy_ema_fast = IntParameter(5, 25, default=9, space='buy', optimize=True)
    buy_ema_slow = IntParameter(15, 50, default=21, space='buy', optimize=True)
    buy_ema_trend = IntParameter(100, 250, default=200, space='buy', optimize=True)
    buy_rsi_threshold = IntParameter(55, 80, default=65, space='buy', optimize=True)

    sell_rsi_threshold = IntParameter(20, 45, default=30, space='sell', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs
        for period in range(5, 51):
            dataframe[f'ema{period}'] = ta.EMA(dataframe, timeperiod=period)
        for period in [100, 150, 200, 250]:
            dataframe[f'ema{period}'] = ta.EMA(dataframe, timeperiod=period)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # ADX for trend strength
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        fast_col = f'ema{self.buy_ema_fast.value}'
        slow_col = f'ema{self.buy_ema_slow.value}'
        trend_val = round(self.buy_ema_trend.value / 50) * 50
        if trend_val < 100:
            trend_val = 100
        trend_col = f'ema{trend_val}'

        # Short entry: death cross in downtrend
        dataframe.loc[
            (
                (dataframe[fast_col] < dataframe[slow_col]) &
                (dataframe[fast_col].shift(1) >= dataframe[slow_col].shift(1)) &
                (dataframe['close'] < dataframe[trend_col]) &
                (dataframe['rsi'] > self.buy_rsi_threshold.value) &
                (dataframe['minus_di'] > dataframe['plus_di']) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        fast_col = f'ema{self.buy_ema_fast.value}'
        slow_col = f'ema{self.buy_ema_slow.value}'

        # Exit short: golden cross or RSI oversold
        dataframe.loc[
            (
                (
                    (dataframe[fast_col] > dataframe[slow_col]) &
                    (dataframe[fast_col].shift(1) <= dataframe[slow_col].shift(1))
                ) |
                (dataframe['rsi'] < self.sell_rsi_threshold.value)
            ),
            'exit_short'] = 1

        return dataframe
