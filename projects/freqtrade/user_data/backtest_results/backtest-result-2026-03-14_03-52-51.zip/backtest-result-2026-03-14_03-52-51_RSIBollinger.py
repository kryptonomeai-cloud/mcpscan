from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class RSIBollinger(IStrategy):
    """RSI oversold + Bollinger Band bounce strategy.
    
    Entry: RSI < 30, price at lower Bollinger, above-average volume.
    Exit: RSI > 70 or price at upper Bollinger.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.05,    # 5% profit → exit immediately
        "30": 0.03,   # 3% profit after 30 min
        "60": 0.02,   # 2% profit after 60 min
        "120": 0.01,  # 1% profit after 120 min
    }

    stoploss = -0.05
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02

    timeframe = '1h'

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bollinger['upperband']
        dataframe['bb_middle'] = bollinger['middleband']
        dataframe['bb_lower'] = bollinger['lowerband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']

        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] < 30) &
                (dataframe['close'] <= dataframe['bb_lower']) &
                (dataframe['volume'] > dataframe['volume_mean'])
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 70) |
                (dataframe['close'] >= dataframe['bb_upper'])
            ),
            'exit_long'] = 1
        return dataframe
