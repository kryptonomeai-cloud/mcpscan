"""
Adaptive RSI Strategy

RSI with dynamically adjusted lookback period based on market volatility.
High volatility → shorter RSI (more responsive)
Low volatility → longer RSI (smoother, fewer false signals)

Entry: adaptive RSI oversold + bullish engulfing + Chaikin Money Flow confirmation
Exit:  adaptive RSI overbought + bearish engulfing
"""

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame
import talib.abstract as ta
import numpy as np


class AdaptiveRSIStrategy(IStrategy):

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.08,
        "60": 0.04,
        "180": 0.025,
        "360": 0.01,
    }

    stoploss = -0.08

    timeframe = '1h'
    startup_candle_count = 100

    # --- Hyperoptable parameters ---
    rsi_min_period = IntParameter(5, 14, default=7, space='buy', optimize=True)
    rsi_max_period = IntParameter(14, 40, default=28, space='buy', optimize=True)
    rsi_entry_threshold = IntParameter(15, 35, default=25, space='buy', optimize=True)
    rsi_exit_threshold = IntParameter(65, 85, default=75, space='sell', optimize=True)
    atr_pct_high = DecimalParameter(1.0, 5.0, default=3.0, decimals=1, space='buy', optimize=True)
    atr_pct_low = DecimalParameter(0.3, 2.0, default=1.0, decimals=1, space='buy', optimize=True)
    cmf_threshold = DecimalParameter(-0.1, 0.2, default=0.05, decimals=2, space='buy', optimize=True)
    require_engulfing = IntParameter(0, 1, default=1, space='buy', optimize=True)
    atr_sl_multiplier = DecimalParameter(1.5, 4.0, default=2.5, decimals=1, space='buy', optimize=True)

    use_custom_stoploss = True

    def custom_stoploss(self, pair: str, trade, current_time, current_rate, current_profit, **kwargs):
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) < 1:
            return self.stoploss

        last = dataframe.iloc[-1]
        atr = last.get('atr', 0)
        if atr > 0 and current_rate > 0:
            sl_distance = atr * self.atr_sl_multiplier.value
            sl_pct = -sl_distance / current_rate
            return max(sl_pct, self.stoploss)

        return self.stoploss

    def _chaikin_money_flow(self, dataframe: DataFrame, period: int = 20) -> DataFrame:
        """Calculate Chaikin Money Flow indicator."""
        mfv = ((dataframe['close'] - dataframe['low']) - (dataframe['high'] - dataframe['close'])) / \
              (dataframe['high'] - dataframe['low'] + 1e-10) * dataframe['volume']
        cmf = mfv.rolling(window=period).sum() / dataframe['volume'].rolling(window=period).sum()
        return cmf

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # ATR and ATR percentage (volatility measure)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['atr_pct'] = (dataframe['atr'] / dataframe['close']) * 100

        # Smoothed ATR percentage for regime detection
        dataframe['atr_pct_smooth'] = dataframe['atr_pct'].rolling(window=10).mean()

        # Calculate RSI for multiple periods (adaptive selection happens in entry/exit)
        for period in range(5, 41):
            dataframe[f'rsi_{period}'] = ta.RSI(dataframe, timeperiod=period)

        # Adaptive RSI: compute based on volatility
        # Map ATR% to RSI period: high vol → short period, low vol → long period
        dataframe['adaptive_rsi_period'] = np.nan
        dataframe['adaptive_rsi'] = np.nan

        for i in range(len(dataframe)):
            atr_pct = dataframe['atr_pct_smooth'].iloc[i]
            if np.isnan(atr_pct):
                continue

            # Linear interpolation between min and max RSI periods
            # High ATR% → min period, Low ATR% → max period
            rsi_min = self.rsi_min_period.value
            rsi_max = self.rsi_max_period.value
            atr_low = self.atr_pct_low.value
            atr_high = self.atr_pct_high.value

            if atr_pct >= atr_high:
                rsi_period = rsi_min
            elif atr_pct <= atr_low:
                rsi_period = rsi_max
            else:
                ratio = (atr_pct - atr_low) / (atr_high - atr_low)
                rsi_period = int(rsi_max - ratio * (rsi_max - rsi_min))

            rsi_period = max(5, min(40, rsi_period))
            col = f'rsi_{rsi_period}'
            if col in dataframe.columns:
                dataframe.iloc[i, dataframe.columns.get_loc('adaptive_rsi_period')] = rsi_period
                dataframe.iloc[i, dataframe.columns.get_loc('adaptive_rsi')] = dataframe[col].iloc[i]

        # Chaikin Money Flow
        dataframe['cmf'] = self._chaikin_money_flow(dataframe, period=20)

        # Candlestick patterns
        dataframe['bullish_engulfing'] = ta.CDLENGULFING(dataframe)
        dataframe['bearish_engulfing'] = ta.CDLENGULFING(dataframe)

        # Simple bullish/bearish candle detection as fallback
        dataframe['bullish_candle'] = (dataframe['close'] > dataframe['open']).astype(int)
        dataframe['bearish_candle'] = (dataframe['close'] < dataframe['open']).astype(int)

        # Previous candle was bearish (for engulfing pattern)
        dataframe['prev_bearish'] = dataframe['bearish_candle'].shift(1)
        dataframe['prev_bullish'] = dataframe['bullish_candle'].shift(1)

        # Manual engulfing: current body engulfs previous body
        dataframe['manual_bull_engulf'] = (
            (dataframe['bullish_candle'] == 1) &
            (dataframe['prev_bearish'] == 1) &
            (dataframe['close'] > dataframe['open'].shift(1)) &
            (dataframe['open'] < dataframe['close'].shift(1))
        ).astype(int)

        dataframe['manual_bear_engulf'] = (
            (dataframe['bearish_candle'] == 1) &
            (dataframe['prev_bullish'] == 1) &
            (dataframe['open'] > dataframe['close'].shift(1)) &
            (dataframe['close'] < dataframe['open'].shift(1))
        ).astype(int)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = (
            (dataframe['adaptive_rsi'] < self.rsi_entry_threshold.value) &
            (dataframe['cmf'] > self.cmf_threshold.value) &
            (dataframe['volume'] > 0)
        )

        # Optionally require engulfing pattern
        if self.require_engulfing.value == 1:
            engulfing = (
                (dataframe['bullish_engulfing'] > 0) |
                (dataframe['manual_bull_engulf'] == 1)
            )
            conditions = conditions & engulfing

        dataframe.loc[conditions, 'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = (
            (dataframe['adaptive_rsi'] > self.rsi_exit_threshold.value)
        )

        # Bearish engulfing strengthens exit signal
        bear_engulf = (
            (dataframe['bearish_engulfing'] < 0) |
            (dataframe['manual_bear_engulf'] == 1)
        )

        dataframe.loc[conditions | bear_engulf, 'exit_long'] = 1

        return dataframe
