from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, RealParameter
from pandas import DataFrame
import talib.abstract as ta
import numpy as np


class MomentumTrendStrategy(IStrategy):
    """Momentum + Trend strategy using ADX, Stochastic RSI, and ATR.

    Entry: ADX > threshold (strong trend), StochRSI oversold,
           price direction confirmed by DI.
    Exit:  StochRSI overbought or trend weakening.
    ATR-based dynamic stop loss.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.10,
        "60": 0.05,
        "120": 0.025,
        "240": 0.01,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.025
    trailing_stop_positive_offset = 0.05
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 60

    # Hyperopt params
    buy_adx_threshold = IntParameter(15, 35, default=20, space='buy', optimize=True)
    buy_stochrsi_threshold = IntParameter(15, 45, default=30, space='buy', optimize=True)
    buy_rsi_threshold = IntParameter(25, 50, default=40, space='buy', optimize=True)

    sell_stochrsi_threshold = IntParameter(65, 90, default=75, space='sell', optimize=True)
    sell_rsi_threshold = IntParameter(60, 85, default=70, space='sell', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14)

        # Stochastic RSI
        rsi = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi'] = rsi
        stoch_rsi_period = 14
        rsi_min = rsi.rolling(stoch_rsi_period).min()
        rsi_max = rsi.rolling(stoch_rsi_period).max()
        rsi_range = rsi_max - rsi_min
        dataframe['stochrsi'] = np.where(rsi_range > 0, ((rsi - rsi_min) / rsi_range) * 100, 50)
        dataframe['stochrsi_k'] = dataframe['stochrsi'].rolling(3).mean()
        dataframe['stochrsi_d'] = dataframe['stochrsi_k'].rolling(3).mean()

        # EMAs
        dataframe['ema20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)

        # ATR for dynamic stops
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['adx'] > self.buy_adx_threshold.value) &
                (dataframe['plus_di'] > dataframe['minus_di']) &
                (dataframe['stochrsi_k'] < self.buy_stochrsi_threshold.value) &
                (dataframe['rsi'] < self.buy_rsi_threshold.value) &
                (dataframe['close'] > dataframe['ema20']) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['stochrsi_k'] > self.sell_stochrsi_threshold.value) |
                (dataframe['rsi'] > self.sell_rsi_threshold.value) |
                (dataframe['plus_di'] < dataframe['minus_di'])
            ),
            'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade, current_time, current_rate,
                        current_profit, after_fill, **kwargs):
        """ATR-based dynamic stop loss."""
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) < 1:
            return self.stoploss

        last_candle = dataframe.iloc[-1]
        atr = last_candle.get('atr', 0)
        if atr == 0:
            return self.stoploss

        atr_stop = -(atr * 2) / current_rate
        return max(atr_stop, self.stoploss)
