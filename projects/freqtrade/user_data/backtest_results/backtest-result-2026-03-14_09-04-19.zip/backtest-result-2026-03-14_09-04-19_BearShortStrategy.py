from freqtrade.strategy import IStrategy, IntParameter, RealParameter
from pandas import DataFrame
import talib.abstract as ta


class BearShortStrategy(IStrategy):
    """Short-selling strategy for bear markets.

    Entry Short: RSI overbought bounce, price below key EMA, MACD confirms downtrend.
    Exit Short:  RSI oversold or MACD histogram turns positive.
    Designed for profiting from downtrends.
    """

    INTERFACE_VERSION = 3
    can_short = True

    minimal_roi = {
        "0": 0.08,
        "60": 0.04,
        "120": 0.02,
        "240": 0.01,
    }

    stoploss = -0.08

    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 50

    # Hyperopt params
    buy_rsi_threshold = IntParameter(45, 70, default=55, space='buy', optimize=True)
    buy_ema_period = IntParameter(15, 50, default=21, space='buy', optimize=True)

    sell_rsi_threshold = IntParameter(25, 45, default=35, space='sell', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1)

        # EMAs
        for period in [15, 20, 21, 25, 30, 35, 40, 45, 50]:
            dataframe[f'ema{period}'] = ta.EMA(dataframe, timeperiod=period)

        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)

        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']
        dataframe['macdhist_prev'] = dataframe['macdhist'].shift(1)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        ema_col = f'ema{self.buy_ema_period.value}'

        # Short when: price below EMA (downtrend), RSI was high and turning down,
        # MACD histogram is negative (bearish momentum)
        dataframe.loc[
            (
                (dataframe['close'] < dataframe[ema_col]) &
                (dataframe['rsi'] > self.buy_rsi_threshold.value) &
                (dataframe['rsi'] < dataframe['rsi_prev']) &  # RSI turning down
                (dataframe['macdhist'] < 0) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Exit short: RSI oversold or MACD turning bullish
        dataframe.loc[
            (
                (dataframe['rsi'] < self.sell_rsi_threshold.value) |
                (
                    (dataframe['macdhist'] > 0) &
                    (dataframe['macdhist_prev'] <= 0)
                )
            ),
            'exit_short'] = 1

        return dataframe
