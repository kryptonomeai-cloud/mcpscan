"""
Donchian Channel + Turtle Trading Strategy

Based on the legendary Turtle Trading system by Richard Dennis.
One of the most well-documented profitable systems in trading history.

Entry: 20-period breakout (new high)
Exit:  10-period breakdown (new low)
Position sizing: ATR-based, risk 1% per trade
Pyramiding: add to winners up to 4 units using adjust_trade_position
"""

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from datetime import datetime


class TurtleStrategy(IStrategy):

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.50,  # High ROI — let the system manage exits via Donchian
    }

    stoploss = -0.10

    timeframe = '1h'
    startup_candle_count = 500  # Need enough for 20-day (480 1h candles)

    position_adjustment_enable = True

    # --- Hyperoptable parameters ---
    entry_period = IntParameter(10, 40, default=20, space='buy', optimize=True)
    exit_period = IntParameter(5, 20, default=10, space='sell', optimize=True)
    atr_period = IntParameter(10, 30, default=20, space='buy', optimize=True)
    atr_sl_multiplier = DecimalParameter(1.0, 4.0, default=2.0, decimals=1, space='buy', optimize=True)
    max_pyramid_units = IntParameter(1, 6, default=4, space='buy', optimize=True)
    pyramid_atr_step = DecimalParameter(0.3, 1.5, default=0.5, decimals=1, space='buy', optimize=True)

    use_custom_stoploss = True

    def custom_stoploss(self, pair: str, trade, current_time, current_rate, current_profit, **kwargs):
        """ATR-based trailing stop."""
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) < 1:
            return self.stoploss

        last = dataframe.iloc[-1]
        atr = last.get('atr', 0)
        if atr > 0 and current_rate > 0:
            sl_distance = atr * self.atr_sl_multiplier.value
            sl_pct = -sl_distance / current_rate
            return max(sl_pct, self.stoploss)

        return self.stoploss

    def adjust_trade_position(self, trade, current_time, current_rate, current_profit,
                               min_stake, max_stake, current_entry_rate, current_exit_rate,
                               current_exit_profit, **kwargs):
        """
        Turtle pyramiding: add to winning positions when price moves
        0.5 ATR above last entry, up to max_pyramid_units.
        """
        if trade.nr_of_successful_entries >= self.max_pyramid_units.value:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if len(dataframe) < 1:
            return None

        last = dataframe.iloc[-1]
        atr = last.get('atr', 0)
        if atr <= 0:
            return None

        # Only pyramid if in profit
        if current_profit < 0.005:
            return None

        # Price must have moved pyramid_atr_step * ATR above entry
        step = atr * self.pyramid_atr_step.value
        required_price = trade.open_rate + (step * trade.nr_of_successful_entries)

        if current_rate >= required_price:
            # Add a unit — same stake as original
            try:
                stake = trade.stake_amount / trade.nr_of_successful_entries
                stake = min(stake, max_stake)
                stake = max(stake, min_stake)
                return stake
            except Exception:
                return None

        return None

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Donchian channels for multiple periods
        for period in range(5, 41):
            # Convert day-periods to candle counts based on timeframe
            # For 1h: 1 day = 24 candles. For flexibility, use raw period * 24
            # But we also support direct period use for shorter timeframes
            candle_period = period * 24 if period <= 40 else period

            # Cap at reasonable values
            candle_period = min(candle_period, 480)

            dataframe[f'dc_upper_{period}'] = dataframe['high'].rolling(window=candle_period).max()
            dataframe[f'dc_lower_{period}'] = dataframe['low'].rolling(window=candle_period).min()
            dataframe[f'dc_mid_{period}'] = (dataframe[f'dc_upper_{period}'] + dataframe[f'dc_lower_{period}']) / 2

        # Also compute for raw candle periods (for sub-daily timeframes)
        for period in [120, 240, 360, 480]:
            dataframe[f'dc_upper_raw_{period}'] = dataframe['high'].rolling(window=period).max()
            dataframe[f'dc_lower_raw_{period}'] = dataframe['low'].rolling(window=period).min()

        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=20)

        # Trend filter
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        entry_p = self.entry_period.value
        upper_col = f'dc_upper_{entry_p}'

        if upper_col not in dataframe.columns:
            upper_col = 'dc_upper_20'

        # Shift by 1 to compare against previous period's high (breakout)
        prev_upper = dataframe[upper_col].shift(1)

        dataframe.loc[
            (
                (dataframe['close'] > prev_upper) &  # Breakout above previous Donchian high
                (dataframe['close'] > dataframe['ema_50']) &  # Above trend
                (dataframe['volume'] > dataframe['volume_mean'] * 0.8) &  # Decent volume
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        exit_p = self.exit_period.value
        lower_col = f'dc_lower_{exit_p}'

        if lower_col not in dataframe.columns:
            lower_col = 'dc_lower_10'

        # Exit when price breaks below exit-period Donchian low
        prev_lower = dataframe[lower_col].shift(1)

        dataframe.loc[
            (
                (dataframe['close'] < prev_lower)
            ),
            'exit_long'] = 1

        return dataframe
