from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class RSIBollinger(IStrategy):
    """RSI oversold + Bollinger Band bounce strategy.
    
    Entry: RSI < 30, price at lower Bollinger, above-average volume.
    Exit: RSI > 70 or price at upper Bollinger.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.06,    # 6% profit → exit immediately
        "30": 0.04,   # 4% profit after 30 min
        "60": 0.025,  # 2.5% profit after 60 min
        "120": 0.015, # 1.5% profit after 120 min
        "240": 0.01,  # 1% profit after 240 min
    }

    stoploss = -0.05
    trailing_stop = True
    trailing_stop_positive = 0.02    # wider trailing: lock in at +2% (was +1%)
    trailing_stop_positive_offset = 0.04  # activate trailing after +4% gain (was +2%)
    startup_candle_count = 20  # need 20 candles for BB/volume indicators

    timeframe = '1h'

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bollinger['upperband']
        dataframe['bb_middle'] = bollinger['middleband']
        dataframe['bb_lower'] = bollinger['lowerband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']

        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] < 28) &  # Stricter entry: deeper oversold
                (dataframe['close'] <= dataframe['bb_lower']) &
                (dataframe['volume'] > dataframe['volume_mean'])
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 65) |  # Earlier exit: take profits sooner
                (dataframe['close'] >= dataframe['bb_upper'])
            ),
            'exit_long'] = 1
        return dataframe
