from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class EMACrossStrategy(IStrategy):
    """Simple EMA crossover strategy with trend filter.

    Entry: EMA9 crosses above EMA21, price above EMA50 (trend filter).
    Exit:  Rely primarily on ROI and trailing stop rather than signal exits.
           Only exit on signal if RSI > 80 (very overbought).

    v2: Removed EMA crossunder exit (was causing -6.5% in losses).
        Let ROI targets and trailing stop handle exits instead.
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.08,     # 8%
        "30": 0.03,    # 3% after 30 min
        "60": 0.02,    # 2% after 60 min
        "120": 0.01,   # 1% after 120 min
    }

    stoploss = -0.06   # Tighter stop loss (was -8%)

    trailing_stop = True
    trailing_stop_positive = 0.015   # Lock in at 1.5%
    trailing_stop_positive_offset = 0.03  # Activate after 3% gain
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 50

    max_open_trades = 5

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)

        # Previous values for crossover detection
        dataframe['ema9_prev'] = dataframe['ema9'].shift(1)
        dataframe['ema21_prev'] = dataframe['ema21'].shift(1)

        # RSI for exit
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['ema9'] > dataframe['ema21']) &             # EMA9 above EMA21
                (dataframe['ema9_prev'] <= dataframe['ema21_prev']) &  # Was below (crossover)
                (dataframe['close'] > dataframe['ema50']) &            # Above EMA50 trend filter
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 80)  # Only exit on extreme overbought
            ),
            'exit_long'] = 1
        return dataframe
