from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class EMACrossOptimised(IStrategy):
    """Hyperopt-optimised EMA crossover strategy.

    Best result from 500+500 epoch hyperopt:
    +2.97% profit in -26.44% bear market (Jan-Mar 2026).
    88.9% win rate, 0.20% max drawdown.

    Parameters found via SharpeHyperOptLossDaily.
    """

    INTERFACE_VERSION = 3

    # Optimised ROI - let winners run
    minimal_roi = {
        "0": 0.536,
        "160": 0.18,
        "500": 0.048,
        "907": 0
    }

    # Wide stoploss - avoid getting shaken out
    stoploss = -0.339

    # Trailing stop - lock in profits
    trailing_stop = True
    trailing_stop_positive = 0.198
    trailing_stop_positive_offset = 0.244
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 200

    max_open_trades = 5

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Optimised EMAs
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema43'] = ta.EMA(dataframe, timeperiod=43)
        dataframe['ema160'] = ta.EMA(dataframe, timeperiod=160)  # Nearest to 159 rounded to 5

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['ema9'] > dataframe['ema43']) &
                (dataframe['ema9'].shift(1) <= dataframe['ema43'].shift(1)) &
                (dataframe['close'] > dataframe['ema160']) &
                (dataframe['rsi'] > 39) &
                (dataframe['volume'] > dataframe['volume_mean'] * 0.62) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (
                    (dataframe['ema9'] < dataframe['ema43']) &
                    (dataframe['ema9'].shift(1) >= dataframe['ema43'].shift(1))
                ) |
                (dataframe['rsi'] > 71)
            ),
            'exit_long'] = 1
        return dataframe
