from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class EMACrossStrategy(IStrategy):
    """Simple EMA crossover strategy with trend filter.

    Entry: EMA9 crosses above EMA21, price above EMA50 (trend filter).
    Exit:  ROI targets and trailing stop only. No exit signals.

    v3: Analysis showed ROI exits were 100% winners (+38 USDT) while
        exit_signal was 100% losers (-65 USDT). Disable exit signal
        entirely and use tighter ROI + trailing to capture profits quickly.
    """

    INTERFACE_VERSION = 3

    # Tighter ROI to take profits quickly before reversals
    minimal_roi = {
        "0": 0.05,     # 5%
        "15": 0.025,   # 2.5% after 15 min
        "30": 0.015,   # 1.5% after 30 min
        "60": 0.01,    # 1% after 60 min
        "120": 0.005,  # 0.5% after 120 min
    }

    stoploss = -0.05   # 5% stop loss

    trailing_stop = True
    trailing_stop_positive = 0.01    # Lock in at 1%
    trailing_stop_positive_offset = 0.02  # Activate after 2% gain
    trailing_only_offset_is_reached = True

    # Disable exit signal entirely — ROI and trailing handle exits
    use_exit_signal = False

    timeframe = '1h'
    startup_candle_count = 50

    max_open_trades = 5

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)

        # Previous values for crossover detection
        dataframe['ema9_prev'] = dataframe['ema9'].shift(1)
        dataframe['ema21_prev'] = dataframe['ema21'].shift(1)

        # RSI for additional filter
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['ema9'] > dataframe['ema21']) &             # EMA9 above EMA21
                (dataframe['ema9_prev'] <= dataframe['ema21_prev']) &  # Was below (crossover)
                (dataframe['close'] > dataframe['ema50']) &            # Above EMA50 trend filter
                (dataframe['rsi'] < 65) &                              # Not already overbought
                (dataframe['volume'] > dataframe['volume_mean'] * 0.5) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # No exit signals — rely on ROI and trailing stop
        return dataframe
