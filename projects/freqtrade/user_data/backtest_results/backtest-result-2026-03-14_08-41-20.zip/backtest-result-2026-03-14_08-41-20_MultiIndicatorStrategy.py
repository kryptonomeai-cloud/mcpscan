from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class MultiIndicatorStrategy(IStrategy):
    """Multi-confirmation strategy: RSI + MACD + Bollinger + EMA.

    Entry: RSI < 35 AND price below lower BB AND MACD histogram turning positive
           AND price above EMA200 (trend filter).
    Exit:  RSI > 70 OR price above upper BB OR MACD histogram turning negative.

    Conservative position sizing (10% per trade, max 5 open trades).
    """

    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.10,     # 10% — let winners run
        "30": 0.03,    # 3% after 30 min
        "60": 0.02,    # 2% after 60 min
        "120": 0.01,   # 1% after 120 min
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.08   # activate trailing after +8% gain
    trailing_only_offset_is_reached = True

    timeframe = '1h'
    startup_candle_count = 200  # need 200 candles for EMA200

    # Position sizing via max_open_trades + stake_amount in config
    # We set max_open_trades here to override config
    max_open_trades = 5

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Bollinger Bands
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bollinger['upperband']
        dataframe['bb_middle'] = bollinger['middleband']
        dataframe['bb_lower'] = bollinger['lowerband']

        # MACD
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']
        dataframe['macdhist_prev'] = dataframe['macdhist'].shift(1)

        # EMAs
        dataframe['ema9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema21'] = ta.EMA(dataframe, timeperiod=21)
        dataframe['ema50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)

        # Volume confirmation
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] < 35) &                          # RSI oversold
                (dataframe['close'] <= dataframe['bb_lower']) &    # Price at/below lower BB
                (dataframe['macdhist'] > 0) &                     # MACD histogram positive
                (dataframe['macdhist_prev'] <= 0) &               # ...and was negative (turning)
                (dataframe['close'] > dataframe['ema200']) &      # Above EMA200 (uptrend)
                (dataframe['volume'] > 0)                         # Non-zero volume
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (
                (dataframe['rsi'] > 70) |                          # RSI overbought
                (dataframe['close'] >= dataframe['bb_upper']) |    # Price at/above upper BB
                (
                    (dataframe['macdhist'] < 0) &                  # MACD histogram negative
                    (dataframe['macdhist_prev'] >= 0)              # ...and was positive (turning)
                )
            ),
            'exit_long'] = 1
        return dataframe
